package com.example.csis3275finalkarlo_justo;

import com.example.csis3275finalkarlo_justo.entities.Salesman;
import com.example.csis3275finalkarlo_justo.respositories.SalesmanRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import java.util.Date;

@SpringBootApplication
public class Csis3275FinalKarloJustoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Csis3275FinalKarloJustoApplication.class, args);
	}

	@Bean
	CommandLineRunner commandLineRunner(SalesmanRepository salesmanRepository) {
		return args -> {

			salesmanRepository.save(new Salesman(123L, "Jessica Lam", 5000, "Washing machine",  new Date()));
			salesmanRepository.save(new Salesman(124L, "Jessica Lam", 5000, "Washing machine",  new Date()));


			salesmanRepository.findAll().forEach(p -> {
				System.out.println(p.getName());
				                                
			});
		};

	}
}
