package com.example.csis3275finalkarlo_justo.respositories;

import com.example.csis3275finalkarlo_justo.entities.Salesman;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesmanRepository extends JpaRepository <Salesman,Long> {
}
