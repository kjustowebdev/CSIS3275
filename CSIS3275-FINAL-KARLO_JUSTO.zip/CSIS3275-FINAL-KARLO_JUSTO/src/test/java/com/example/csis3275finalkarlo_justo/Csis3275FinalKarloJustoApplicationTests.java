package com.example.csis3275finalkarlo_justo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Csis3275FinalKarloJustoApplicationTests {

	@Test
	void contextLoads() {
	}

}
