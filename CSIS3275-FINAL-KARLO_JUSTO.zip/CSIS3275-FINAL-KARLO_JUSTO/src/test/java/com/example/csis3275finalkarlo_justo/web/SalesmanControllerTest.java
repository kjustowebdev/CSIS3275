package com.example.csis3275finalkarlo_justo.web;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SalesmanControllerTest {

    @Test
    void salesman() {
    }

    @Test
    void delete() {
    }
}