package com.example.csis3275finalkarlo_justo.entities;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SalesmanTest {

    @Test
    void getId() {
    }

    @Test
    void getName() {
    }

    @Test
    void getAmount() {
    }

    @Test
    void getItem() {
    }

    @Test
    void getDot() {
    }

    @Test
    void setId() {
    }

    @Test
    void setName() {
    }

    @Test
    void setAmount() {
    }

    @Test
    void setItem() {
    }

    @Test
    void setDot() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }
}